DROP TABLE IF EXISTS `#__immobrowse`;
