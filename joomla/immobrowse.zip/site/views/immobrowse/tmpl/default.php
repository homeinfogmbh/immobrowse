<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1>Customer ID: <?php echo $this->cid; ?></h1>
